import React, { useState } from 'react';
import {
  ShieldCheck,
  Sparkles,
  DollarSign,
  Copy,
  Check,
  Flame,
  Award,
  Video,
  Share2,
  Mail,
  Zap,
  CheckCircle2,
  ExternalLink,
  Crown,
  Sword,
  Target,
  MessageSquare,
  Download,
  Filter,
  TrendingUp,
  Users,
  HelpCircle,
  Clock,
  Send
} from 'lucide-react';
import { sendPurchaseAlertToOwner, OWNER_NOTIFICATION_EMAIL } from '../services/emailReportService';

interface AdCampaign {
  id: string;
  category: 'tiktok' | 'reddit' | 'twitter' | 'facebook' | 'email' | 'affiliate_recruit' | 'faq';
  title: string;
  badge: string;
  platform: string;
  recommendedAudience: string;
  bestTimes?: string;
  content: string;
  displayContent: React.ReactNode;
}

export const CommercialSalesKit: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'campaign' | 'pitch' | 'pricing' | 'preview'>('campaign');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Direct PayPal Checkout URLs for Ty Birchfield
  const PAYPAL_STARTER_URL =
    'https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=tybirchfield42@gmail.com&item_name=Cash+Captain+Marketeer+Starter+License&amount=47.00&currency_code=USD';
  const PAYPAL_PRO_URL =
    'https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=tybirchfield42@gmail.com&item_name=Cash+Captain+Marketeer+Captain+Pro+License&amount=97.00&currency_code=USD';
  const PAYPAL_LIFETIME_URL =
    'https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=tybirchfield42@gmail.com&item_name=Cash+Captain+Marketeer+Founder+Lifetime+License&amount=197.00&currency_code=USD';

  const [previewSelectedTier, setPreviewSelectedTier] = useState<'starter' | 'pro' | 'lifetime'>('pro');

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2200);
  };

  const adCampaigns: AdCampaign[] = [
    // 1. TikTok Script #1: The Reddit Ban Problem
    {
      id: 'tiktok-ban-problem',
      category: 'tiktok',
      title: 'TikTok/Reels #1: The Affiliate Link Ban Epidemic (Problem-Agitate-Solve)',
      badge: 'High Viral Potential',
      platform: 'TikTok, Instagram Reels, YouTube Shorts',
      recommendedAudience: 'Side hustlers, beginner affiliate marketers, passive income seekers',
      bestTimes: '12:00 PM - 2:00 PM or 7:00 PM - 9:00 PM EST',
      content: `[Visual: Talking head or split screen showing Reddit comment getting instantly removed]\n\n"Stop pasting your affiliate link into Reddit comments and wondering why your account got banned in 3 minutes.\n\nHere's what 6-figure affiliate earners do instead in 2026: They use Cash Captain Marketeer by Ty Birchfield.\n\nWatch this: You drop in your product link. In under 5 seconds, the AI spider searches Reddit, Quora, and niche forums for people actively asking: 'What's the best tool for this?' or 'Does anyone have a recommendation?'\n\nThen, instead of spamming, Cash Captain generates a helpful, compliance-safe expert answer with your tracking link embedded naturally.\n\nThe result? Zero bans, high upvotes, and automated clicks from people who are ready to buy right now.\n\nType 'CAPTAIN' in the comments or tap the link in bio to grab your lifetime license before the price increases!"`,
      displayContent: (
        <div className="space-y-2 text-xs font-mono text-slate-200">
          <p><span className="text-amber-400 font-bold">🎬 [Visual 0-4s]:</span> Creator looking directly into camera with shocked expression, text overlay: <em>"Why your affiliate links get banned in 3 minutes"</em></p>
          <p><span className="text-blue-400 font-bold">🗣️ Hook (0-5s):</span> "Stop pasting your affiliate link into Reddit comments and wondering why your account got permabanned in 3 minutes."</p>
          <p><span className="text-emerald-400 font-bold">💡 Solution (6-20s):</span> "Here is what 6-figure affiliate earners do instead in 2026: They use <strong>Cash Captain Marketeer</strong> by Ty Birchfield. You drop in any product link, and in 5 seconds the AI spider finds people actively begging for recommendations on Reddit, Quora, and high-traffic forums."</p>
          <p><span className="text-purple-400 font-bold">⚡ Demonstration (21-35s):</span> "It drafts a compliance-safe, helpful expert answer with your tracking link naturally embedded, and deploys it hands-free on autopilot."</p>
          <p><span className="text-pink-400 font-bold">🚀 Call To Action (36-45s):</span> "Drop a comment with 'CAPTAIN' or tap the bio link to claim Cash Captain Marketeer before the launch discount expires!"</p>
        </div>
      )
    },

    // 2. TikTok Script #2: The 24/7 AI Buyer Army
    {
      id: 'tiktok-buyer-army',
      category: 'tiktok',
      title: 'TikTok/Reels #2: How I Automated 100+ Daily Buyer Inquiries Hands-Free',
      badge: 'Behind The Scenes Case Study',
      platform: 'TikTok, Instagram Reels, YouTube Shorts',
      recommendedAudience: 'Entrepreneurs, solopreneurs, digital marketers',
      bestTimes: '8:00 AM - 10:00 AM or 6:00 PM - 8:00 PM EST',
      content: `[Visual: Screen recording of Cash Captain Marketeer scanning threads and auto-dispatching]\n\n"What if you had an AI employee that worked 24 hours a day, 7 days a week, doing nothing but finding people who want to buy your affiliate offers?\n\nThat's literally what Cash Captain Marketeer does.\n\nMost people spend 4 hours a day searching forums, crafting pitches, and hoping they don't get blocked.\n\nWith Cash Captain, you just paste your offer link once. The AI tracks real-time high-intent buying discussions, writes persuasive problem-solving recommendations, and places your link on 100% autopilot.\n\nNo paid Facebook ads. No inventory. No spam.\n\nGrab your copy today via the link in bio. All for cash, and cash for all!"`,
      displayContent: (
        <div className="space-y-2 text-xs font-mono text-slate-200">
          <p><span className="text-amber-400 font-bold">🎬 [Visual 0-4s]:</span> Show screen recording of Cash Captain Marketeer scanning threads and auto-dispatching links live.</p>
          <p><span className="text-blue-400 font-bold">🗣️ Hook (0-6s):</span> "What if you had an AI software working 24 hours a day doing nothing but finding people who want to buy your affiliate offers?"</p>
          <p><span className="text-emerald-400 font-bold">💡 Body (7-25s):</span> "That is exactly what <strong>Cash Captain Marketeer</strong> does. Most affiliate marketers waste 4 hours every day hunting for leads. With Cash Captain, you paste 1 link. The radar finds hot discussions, generates value answers, and places the link automatically."</p>
          <p><span className="text-purple-400 font-bold">🚀 CTA (26-35s):</span> "Check the link in my bio to get your license directly from creator Ty Birchfield!"</p>
        </div>
      )
    },

    // 3. Reddit Guerilla Post: Case Study Style
    {
      id: 'reddit-case-study',
      category: 'reddit',
      title: 'Reddit Post: "How I solved the affiliate link ban problem with autonomous AI"',
      badge: 'Guerilla / Zero-Spam Format',
      platform: 'r/AffiliateMarketing, r/SideHustle, r/Entrepreneur, r/passive_income',
      recommendedAudience: 'Reddit community members tired of bans & looking for automated organic traffic',
      bestTimes: 'Tuesday & Thursday mornings (8:00 AM - 11:00 AM EST)',
      content: `Title: How I stopped getting affiliate links banned on Reddit and automated buyer intent discovery\n\nHey everyone,\n\nIf you've done affiliate marketing for more than 5 minutes, you already know the worst feeling:\n\nYou spend 15 minutes writing a helpful recommendation on a forum or subreddit, leave your link, and 3 minutes later: [Removed by Moderator] and an account ban.\n\nThe problem isn't the link—it's that moderators hate low-effort self-promotion, and finding genuine "ready-to-buy" questions manually takes 20+ hours a week.\n\nI built a tool called Cash Captain Marketeer to fix this exact workflow:\n\n1. Autonomous Intent Radar: Scans Reddit, Quora, and niche community feeds for users explicitly asking "What should I use for X?" or "Any alternatives to Y?"\n2. Compliance-First Content Engine: Generates deep, objective pros/cons answers that pass community filters because they genuinely help the OP.\n3. Automatic Link Placement: Injects your tracking link organically into the resolution.\n4. Micro-Search Embeds: Can embed interactive search widgets so readers test the tool before clicking through.\n\nNo ad spend required, zero spam, and completely hands-free.\n\nIf anyone is struggling with organic distribution or link bans, feel free to ask questions below—happy to share what we learned building this!`,
      displayContent: (
        <div className="space-y-2 text-xs text-slate-200">
          <p className="font-bold text-amber-400">📌 Recommended Subreddits: r/AffiliateMarketing, r/SideHustle, r/Entrepreneur</p>
          <div className="bg-[#0f172a] p-3 rounded border border-[#334155] space-y-2 font-mono">
            <p className="font-bold text-white">Title: How I stopped getting affiliate links banned on Reddit and automated buyer intent discovery</p>
            <p>Hey everyone,</p>
            <p>If you've done affiliate marketing for more than 5 minutes, you already know the worst feeling: you spend 15 minutes writing a recommendation, drop your link, and 3 minutes later: <em>[Removed by AutoModerator]</em>.</p>
            <p>The problem is low-effort self-promotion. I built <strong>Cash Captain Marketeer</strong> to automate this properly:</p>
            <p>• Scans live forum discussions for users actively asking to buy or compare tools.<br />
            • Generates objective, value-first answers that moderators love and approve.<br />
            • Injects tracking tags naturally into the solution.</p>
            <p>Happy to share the workflow with anyone trying to scale organic affiliate clicks!</p>
          </div>
        </div>
      )
    },

    // 4. Twitter / X Viral 10-Tweet Master Thread
    {
      id: 'twitter-thread',
      category: 'twitter',
      title: 'Twitter/X Viral Thread: "Why 95% of Affiliate Marketers Make $0 (And The AI Fix)"',
      badge: 'High Engagement Thread',
      platform: 'Twitter / X',
      recommendedAudience: 'Tech Twitter, #buildinpublic, Affiliate Marketers, Indie Hackers',
      bestTimes: 'Monday - Wednesday at 9:00 AM or 1:00 PM EST',
      content: `1/10\n95% of affiliate marketers make $0.\n\nThey spam links in Twitter replies, get shadowbanned, and give up.\n\nMeanwhile, the top 5% are using autonomous AI agents to capture buyers right at the moment of intent.\n\nHere is how Cash Captain Marketeer changes the game 🧵👇\n\n2/10\nThe Old Way of Affiliate Marketing is Dead:\n- Spending $500 on Facebook ads that get rejected\n- Spending 4 hours daily copying and pasting links\n- Getting banned from Reddit communities\n\n3/10\nThe New Way: High-Intent Autonomous Scraping.\nInstead of pitching cold leads, you only speak to people who are ALREADY with credit card in hand asking for recommendations.\n\n4/10\nThat's why @TyBirchfield created Cash Captain Marketeer.\n"Cash Captain: All in One, Cash for All!"\n\n5/10\nHow the 3-step engine works:\n1️⃣ Input any affiliate URL or offer.\n2️⃣ Cash Captain's spider searches forums and communities for live buyer questions.\n3️⃣ It generates an in-depth, compliant answer and deploys it automatically.\n\n6/10\nNotice the difference:\nSpammer: "Check out this link [spam link]"\nCash Captain: "Here are 3 tested solutions to your specific bottleneck... [compliant contextual breakdown with tracking link]"\n\n7/10\nModerators don't ban it because it actually solves the user's issue.\nAnd readers click the link because it's the exact answer they were searching for.\n\n8/10\nFeatures built into Cash Captain:\n✅ Autonomous Radar & Web Scraping\n✅ Anti-Ban Compliance Shield\n✅ Micro-Search Box Generators\n✅ Live Click & Conversion Postbacks\n\n9/10\nAvailable now in 3 tiers:\n• Starter: $47 (5 active offers)\n• Captain Pro: $97 (Unlimited offers + Auto-Placement)\n• Founder Lifetime: $197 (Pay once, own forever)\n\n10/10\nReady to put your affiliate business on full auto-pilot?\nGet instant access via PayPal: [Insert Cash Captain Marketeer URL]\n\nRT the first tweet if you found this valuable! ⚔️`,

      displayContent: (
        <div className="space-y-2 text-xs text-slate-200">
          <p className="font-bold text-amber-400">🧵 10-Tweet Viral Twitter/X Framework</p>
          <div className="bg-[#0f172a] p-3 rounded border border-[#334155] space-y-1.5 font-mono text-[11px]">
            <p className="text-blue-300 font-bold">Tweet 1 (Hook):</p>
            <p>95% of affiliate marketers make $0 because they paste links like spammers and get shadowbanned.<br />The top 5% use autonomous AI agents to capture buyers right at the moment of intent.<br />Here is how Cash Captain Marketeer by @TyBirchfield changes the game 🧵👇</p>
            <p className="text-blue-300 font-bold pt-2">Tweet 5 (Mechanism):</p>
            <p>1️⃣ Input any affiliate link.<br />2️⃣ Cash Captain scans forums for live buyer questions.<br />3️⃣ Generates compliant answers and auto-places the link hands-free.</p>
            <p className="text-blue-300 font-bold pt-2">Tweet 10 (Direct CTA):</p>
            <p>Get instant lifetime access to Cash Captain Marketeer via PayPal directly from Ty Birchfield!</p>
          </div>
        </div>
      )
    },

    // 5. Facebook Groups Value Drop Post
    {
      id: 'facebook-value-drop',
      category: 'facebook',
      title: 'Facebook Groups: High-Value Giveaway / Software Demo Post',
      badge: 'Organic Lead Magnet',
      platform: 'Affiliate Marketing Facebook Groups (10k-100k member groups)',
      recommendedAudience: 'ClickBank, Digistore24, WarriorPlus, Amazon Associates groups',
      bestTimes: 'Evenings (6:30 PM - 8:30 PM EST)',
      content: `⚔️ "All for Cash, and Cash for All!"\n\nQuick question for fellow affiliate marketers:\n\nHow many hours a week do you spend manually writing forum replies, trying to get people to click your affiliate links without moderators deleting your post?\n\nI was spending 15+ hours a week on this until I built Cash Captain Marketeer.\n\nNow:\n1. I drop my affiliate link into the software.\n2. The AI spider scans Reddit, Quora, and discussion boards for people actively asking to buy that type of product.\n3. It writes a genuine, helpful answer and places the link automatically on autopilot.\n\nNo paid ads required. No link bans.\n\nI'm sharing a full walkthrough demo of how this works today. If you'd like to see it, just comment "CAPTAIN" below and I'll send you the details!`,
      displayContent: (
        <div className="space-y-2 text-xs text-slate-200">
          <p className="font-bold text-amber-400">👥 Target Groups: ClickBank Marketers, Affiliate Marketing Ninjas, SaaS Affiliates</p>
          <div className="bg-[#0f172a] p-3 rounded border border-[#334155] space-y-2">
            <p className="font-bold text-white">⚔️ "All for Cash, and Cash for All!"</p>
            <p>Quick question for the group: How many hours a week do you spend manually searching forums and trying to get clicks without moderators deleting your links?</p>
            <p>I was spending 15+ hours until I created <strong>Cash Captain Marketeer</strong>. Now you drop in 1 link, the AI scans Reddit and Quora for people actively begging for recommendations, and auto-places value-first answers.</p>
            <p className="font-bold text-emerald-400">Want the full demo link? Comment "CAPTAIN" below and I'll message you!</p>
          </div>
        </div>
      )
    },

    // 6. Solo Ad & Email Swipe (For Email Lists & Udimi)
    {
      id: 'solo-ad-swipe',
      category: 'email',
      title: 'Solo Ad / Email Swipe: "The AI agent that hunts down buyers for you"',
      badge: 'High CTR Email Swipe',
      platform: 'Solo Ads (Udimi), Affiliate Newsletters, Email Broadcasts',
      recommendedAudience: 'Make Money Online / Affiliate Marketing Email Subscribers',
      bestTimes: 'Tuesday or Thursday at 10:00 AM EST',
      content: `Subject: [AI Tool] The autonomous agent that places your affiliate links...\nAlternative Subject: Stop pasting affiliate links manually (try this)\n\nHey [First Name],\n\nWhat if you never had to manually search for buyer traffic again?\n\nMost affiliate marketers fail because they spend hours dropping links where nobody wants them.\n\nCash Captain Marketeer flips the script.\n\nCreated by Ty Birchfield, this autonomous AI engine does one thing:\nIt tracks down live internet discussions where buyers are actively asking for recommendations, writes compliance-safe expert answers, and places your affiliate links on 100% autopilot.\n\nHere's why affiliate pros are switching to Cash Captain Marketeer:\n-> Zero ad spend needed\n-> 100% hands-free autonomous scraping\n-> Zero link bans (moderator-approved value copy)\n-> Embedded micro-search utilities\n\nClick the link below to see Cash Captain Marketeer in action and claim your license before prices go up:\n\n👉 [Claim Your Cash Captain Marketeer License]\n\nAll for cash, and cash for all!\n\nTo your success,\nTy Birchfield`,
      displayContent: (
        <div className="space-y-2 text-xs text-slate-200">
          <p className="font-bold text-amber-400">📧 High-CTR Solo Ad / Newsletter Swipe</p>
          <div className="bg-[#0f172a] p-3 rounded border border-[#334155] space-y-2 font-mono">
            <p><span className="text-emerald-400 font-bold">Subject:</span> [AI Tool] The autonomous agent that places your affiliate links...</p>
            <p>Hey [First Name],</p>
            <p>What if you never had to manually hunt down buyer traffic again?</p>
            <p>Most affiliate marketers fail because they drop links where nobody wants them. <strong>Cash Captain Marketeer</strong> by <strong>Ty Birchfield</strong> flips the script: it finds live discussions where people are actively begging for recommendations, and auto-places compliance-safe answers on autopilot.</p>
            <p>👉 <span className="text-amber-400 underline">Claim Your Cash Captain Marketeer License (PayPal Instant Access)</span></p>
          </div>
        </div>
      )
    },

    // 7. 50% Commission Affiliate Recruiter Pitch
    {
      id: 'affiliate-recruitment',
      category: 'affiliate_recruit',
      title: 'Affiliate Partner Recruitment: "Earn 50% Commission Promoting Cash Captain"',
      badge: 'Partner Recruiting Swipe',
      platform: 'Direct Outreach, YouTube Affiliate Channels, Influencer DMs',
      recommendedAudience: 'Marketers with an audience who want high-converting software to promote',
      content: `Hey [Name],\n\nLove your content around affiliate marketing tools and side hustles.\n\nI created Cash Captain Marketeer—an autonomous AI agent that finds Reddit/Quora buyer discussions and places affiliate links hands-free.\n\nOur launch conversions on our $47, $97, and $197 packages are performing exceptionally well, and I'd love to offer you a 50% commission partner deal directly through PayPal.\n\nIf you'd like to test a free review copy of the software and see how it works for your audience, let me know where to send your access!\n\nBest,\nTy Birchfield\nCreator, Cash Captain Marketeer\ntybirchfield42@gmail.com`,
      displayContent: (
        <div className="space-y-2 text-xs text-slate-200">
          <p className="font-bold text-amber-400">🤝 Partner Pitch: Recruit Affiliates to Sell Cash Captain For You (50% PayPal Split)</p>
          <div className="bg-[#0f172a] p-3 rounded border border-[#334155] space-y-2 font-mono">
            <p>Hey [Name],</p>
            <p>Love your content around affiliate marketing tools. I created <strong>Cash Captain Marketeer</strong>—an autonomous AI agent that finds live buyer discussions and auto-places affiliate links hands-free.</p>
            <p>I would love to set you up with a <strong>50% commission partner deal</strong> paid direct via PayPal on every $47, $97, and $197 license.</p>
            <p>Would you like a free review copy to test out? Let me know!</p>
            <p className="text-amber-300 font-bold">— Ty Birchfield (tybirchfield42@gmail.com)</p>
          </div>
        </div>
      )
    },

    // 8. Objection Busters & Fast-Action FAQ
    {
      id: 'faq-objections',
      category: 'faq',
      title: 'Objection Busters & Buyer FAQ: Copy-Paste Answers for Skeptics',
      badge: 'Sales Closing Responses',
      platform: 'Comment Sections, DMs, Support Inquiries',
      recommendedAudience: 'Prospective buyers who ask questions in comments or direct messages',
      content: `Q: Is this allowed on Reddit and forums?\nA: Yes! Unlike spam bots that blindly dump links, Cash Captain Marketeer creates comprehensive, value-driven answers that address the user's specific problem first. The link is only included contextually, keeping posts compliant with community moderation rules.\n\nQ: Does it work with ClickBank, Digistore24, and SaaS affiliate links?\nA: Yes, it supports any valid URL or affiliate network link (ClickBank, Amazon, SaaS affiliate programs, WarriorPlus, CJ Affiliate, etc.).\n\nQ: Do I need any coding knowledge?\nA: Zero. You simply paste your link into the dashboard, and the AI agent handles the scraping, copy generation, and placement automatically.\n\nQ: How do I get access after paying?\nA: Access is instant! As soon as your PayPal checkout completes, your license is active immediately.`,
      displayContent: (
        <div className="space-y-2.5 text-xs text-slate-200">
          <p className="font-bold text-amber-400">❓ Instant Objection Handlers (Keep on hand for comment replies)</p>
          <div className="bg-[#0f172a] p-3 rounded border border-[#334155] space-y-2">
            <p><strong className="text-blue-300">Q: Will my affiliate links get banned?</strong><br />
            <span className="text-slate-300">A: No! Cash Captain writes comprehensive, value-first problem solving answers that pass Reddit & forum AutoModerator filters.</span></p>
            <p><strong className="text-blue-300">Q: What affiliate networks are supported?</strong><br />
            <span className="text-slate-300">A: Any network! ClickBank, WarriorPlus, Amazon, ShareASale, CJ, SaaS affiliate links, and private partner programs.</span></p>
            <p><strong className="text-blue-300">Q: Do I need technical or coding skills?</strong><br />
            <span className="text-slate-300">A: Zero. You paste your product link and the AI handles 100% of the intent scraping and placement.</span></p>
          </div>
        </div>
      )
    }
  ];

  const filteredCampaigns =
    selectedCategory === 'all'
      ? adCampaigns
      : adCampaigns.filter((c) => c.category === selectedCategory);

  const downloadAllSwipes = () => {
    let text = `# Cash Captain Marketeer™ — Master Advertising & Copywriting Swipes\n`;
    text += `Sole Proprietary Entity: Ty Birchfield\nPayPal Payments To: tybirchfield42@gmail.com\n\n`;
    text += `==========================================================\n\n`;

    adCampaigns.forEach((c) => {
      text += `### [${c.platform}] ${c.title}\n`;
      text += `Target Audience: ${c.recommendedAudience}\n`;
      if (c.bestTimes) text += `Best Posting Window: ${c.bestTimes}\n`;
      text += `\n-- CONTENT --\n${c.content}\n\n`;
      text += `----------------------------------------------------------\n\n`;
    });

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'CashCaptainMarketeer_Ad_Campaigns_Ty_Birchfield.txt';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Brand & Ownership Header */}
      <div className="bg-gradient-to-r from-amber-950/60 via-[#1e293b] to-blue-950/60 p-6 rounded-2xl border border-amber-500/30 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#334155]/80">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 text-xl">
              ⚔️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Cash Captain Marketeer™
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono font-bold border border-amber-500/40">
                  By Ty Birchfield
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#94a3b8]">
                Sole Proprietary Property of Ty Birchfield &bull; Commercial Launch & Multi-Channel Advertising Suite
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs text-amber-400 bg-amber-500/10 px-3 py-1 rounded-lg border border-amber-500/20 font-bold">
              "Cash Captain: All in One, Cash for All!"
            </span>
          </div>

        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2 pt-4 overflow-x-auto">
          <button
            onClick={() => setActiveTab('campaign')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'campaign'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-extrabold'
                : 'bg-[#0f172a] text-[#94a3b8] hover:text-white border border-[#334155]'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-orange-500" />
            <span>Ad Campaigns & Viral Swipes ({adCampaigns.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('pitch')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'pitch'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-extrabold'
                : 'bg-[#0f172a] text-[#94a3b8] hover:text-white border border-[#334155]'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span>Core Selling Points & Angles</span>
          </button>

          <button
            onClick={() => setActiveTab('pricing')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'pricing'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-extrabold'
                : 'bg-[#0f172a] text-[#94a3b8] hover:text-white border border-[#334155]'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>PayPal Pricing Tiers ($47, $97, $197)</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'preview'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-extrabold'
                : 'bg-[#0f172a] text-[#94a3b8] hover:text-white border border-[#334155]'
            }`}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>Live Sales Page Preview</span>
          </button>
        </div>
      </div>

      {/* TAB 1: ADVERTISING CAMPAIGNS & SWIPES */}
      {activeTab === 'campaign' && (
        <div className="space-y-6">
          {/* Quick Platform Filter Toolbar & Download */}
          <div className="bg-[#1e293b] p-4 rounded-xl border border-[#334155] flex flex-col md:flex-row items-center justify-between gap-3 shadow">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5 text-amber-400" />
                <span>Filter Channels:</span>
              </span>
              {[
                { id: 'all', label: 'All Channels' },
                { id: 'tiktok', label: '📱 TikTok & Shorts' },
                { id: 'reddit', label: '🤖 Reddit Guerilla' },
                { id: 'twitter', label: '🧵 Twitter / X' },
                { id: 'facebook', label: '👥 FB Groups' },
                { id: 'email', label: '📧 Solo Ads & Email' },
                { id: 'affiliate_recruit', label: '🤝 50% Partner Pitch' },
                { id: 'faq', label: '❓ FAQ Objection Handlers' }
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setSelectedCategory(f.id)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium transition cursor-pointer ${
                    selectedCategory === f.id
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-[#0f172a] text-slate-400 hover:text-white border border-[#334155]'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <button
              onClick={downloadAllSwipes}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer shrink-0"
              title="Download all advertising copy as a text file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download All Copy (.txt)</span>
            </button>
          </div>

          {/* Cards List */}
          <div className="grid grid-cols-1 gap-5">
            {filteredCampaigns.map((ad) => (
              <div
                key={ad.id}
                className="bg-[#1e293b] rounded-xl p-5 sm:p-6 border border-[#334155] shadow-lg space-y-4 hover:border-slate-500/50 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#334155]">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {ad.badge}
                      </span>
                      <span className="text-xs text-[#94a3b8] font-mono">
                        Platform: <strong className="text-white">{ad.platform}</strong>
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-white mt-1">
                      {ad.title}
                    </h3>
                  </div>

                  <button
                    onClick={() => handleCopy(ad.content, ad.id)}
                    className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-[#334155] flex items-center gap-1.5 cursor-pointer self-start sm:self-auto shrink-0 transition"
                  >
                    {copiedKey === ad.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-amber-400" />
                        <span>Copy Swipe Copy</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Target Audience & Posting Guidance */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] bg-[#0f172a]/70 p-2.5 rounded-lg border border-[#334155]/60 text-slate-300">
                  <div>
                    <span className="text-slate-400 font-bold">🎯 Target Audience:</span> {ad.recommendedAudience}
                  </div>
                  {ad.bestTimes && (
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400 shrink-0" />
                      <span className="text-slate-400 font-bold">Best Posting Time:</span> {ad.bestTimes}
                    </div>
                  )}
                </div>

                {/* Visual Display */}
                {ad.displayContent}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: CORE SELLING POINTS & POSITIONING */}
      {activeTab === 'pitch' && (
        <div className="space-y-4">
          <div className="bg-[#1e293b] p-6 rounded-xl border border-[#334155] shadow-lg space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              The 4 Unbeatable Selling Points of Cash Captain Marketeer
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155] space-y-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block">
                  1. Zero Manual Work (100% Hands-Free)
                </span>
                <h4 className="text-sm font-bold text-white">
                  "Plug in 1 Link &rarr; 100+ Live Buyer Placements"
                </h4>
                <p className="text-xs text-[#94a3b8] leading-relaxed">
                  Competitors force users to copy and paste links manually. Cash Captain Marketeer runs on full auto-pilot, scraping buyer inquiries and deploying contextual replies automatically.
                </p>
              </div>

              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155] space-y-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider block">
                  2. Anti-Ban Compliance Shield
                </span>
                <h4 className="text-sm font-bold text-white">
                  "Value-First Helpful AI That Pass Community Moderation"
                </h4>
                <p className="text-xs text-[#94a3b8] leading-relaxed">
                  Raw affiliate links get banned in 3 minutes on Reddit, Quora, and Facebook Groups. Cash Captain generates technical, problem-solving answers that moderators approve.
                </p>
              </div>

              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155] space-y-2">
                <span className="text-xs font-bold text-blue-400 uppercase tracking-wider block">
                  3. Proprietary Micro-Search Engine Hubs
                </span>
                <h4 className="text-sm font-bold text-white">
                  "Interactive Utility Search Boxes with Embedded Tracking"
                </h4>
                <p className="text-xs text-[#94a3b8] leading-relaxed">
                  Instead of pushing cold sales pages, Cash Captain deploys interactive micro-search utilities and ROI calculators that pre-frame visitors before sending them to checkout.
                </p>
              </div>

              <div className="bg-[#0f172a] p-4 rounded-lg border border-[#334155] space-y-2">
                <span className="text-xs font-bold text-purple-400 uppercase tracking-wider block">
                  4. Direct PayPal Checkout (No 30% App Store Tax)
                </span>
                <h4 className="text-sm font-bold text-white">
                  "100% Direct Profit Straight to Your Pocket"
                </h4>
                <p className="text-xs text-[#94a3b8] leading-relaxed">
                  By selling directly on the web through PayPal, buyers get instant access with zero middleman app store fees, keeping 100% of profit margins intact.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: PRICING TIERS & CHECKOUT */}
      {activeTab === 'pricing' && (
        <div className="space-y-6">
          <div className="bg-[#1e293b] p-6 rounded-xl border border-[#334155] shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-5 border-b border-[#334155]">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-emerald-400" />
                  Commercial Licensing Packages &bull; Direct PayPal Checkout
                </h3>
                <p className="text-xs text-[#94a3b8]">
                  Official 1-Click PayPal Checkout &bull; Instant Automated Software License Delivery
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-amber-400 bg-amber-950/60 px-3 py-1 rounded-full border border-amber-800/80 font-semibold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  PayPal Verified Merchant
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Tier 1: Starter */}
              <div className="bg-[#0f172a] p-5 rounded-xl border border-[#334155] flex flex-col justify-between space-y-4">
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Starter Marketeer
                  </span>
                  <div className="text-3xl font-extrabold text-white mt-1 mb-2">
                    $47<span className="text-xs text-[#94a3b8] font-normal"> one-time license</span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Perfect for solo affiliate marketers launching their first automated campaigns.
                  </p>
                  <ul className="text-xs text-slate-300 space-y-2 mt-4">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Up to 5 Active Affiliate Offers</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Autonomous AI Web Scraping</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>Zero-Ban Compliance Copy</span>
                    </li>
                  </ul>
                </div>

                <div className="space-y-2 pt-2">
                  <a
                    href={PAYPAL_STARTER_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      sendPurchaseAlertToOwner({
                        tierName: 'Starter Marketeer ($47)',
                        amount: 47,
                        timestamp: new Date().toLocaleString()
                      });
                    }}
                    className="w-full py-3 px-4 rounded-xl bg-[#ffc439] hover:bg-[#f6bb32] text-[#003087] text-xs font-black transition-all text-center flex items-center justify-center gap-2 shadow-md hover:shadow-lg cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
                  >
                    <span className="font-extrabold italic text-sm text-[#003087]">Pay</span><span className="font-extrabold italic text-sm text-[#0079c1]">Pal</span>
                    <span className="border-l border-[#003087]/30 pl-2 font-bold text-xs text-[#003087]">Pay $47 with PayPal</span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#003087]" />
                  </a>
                  <p className="text-[10px] text-center text-slate-400">
                    🔒 Direct PayPal &bull; Major Cards Accepted
                  </p>
                </div>
              </div>

              {/* Tier 2: Recommended */}
              <div className="bg-gradient-to-b from-[#1e293b] to-blue-950/80 p-5 rounded-xl border-2 border-amber-500 shadow-xl flex flex-col justify-between space-y-4 relative">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-3 py-0.5 rounded-full shadow">
                  Most Popular &bull; Captain Pro
                </div>
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                    Captain Pro License
                  </span>
                  <div className="text-3xl font-extrabold text-white mt-1 mb-2">
                    $97<span className="text-xs text-[#94a3b8] font-normal"> full license</span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Unlimited automated buyer placement, micro-search tools, and full auto-pilot.
                  </p>
                  <ul className="text-xs text-slate-300 space-y-2 mt-4">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span><strong>Unlimited</strong> Active Offers</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>100% Hands-Free Auto-Placement</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>Interactive Micro-Search Hubs</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>Affiliate Pro Webhook Sync</span>
                    </li>
                  </ul>
                </div>

                <div className="space-y-2 pt-2">
                  <a
                    href={PAYPAL_PRO_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      sendPurchaseAlertToOwner({
                        tierName: 'Captain Pro License ($97)',
                        amount: 97,
                        timestamp: new Date().toLocaleString()
                      });
                    }}
                    className="w-full py-3.5 px-4 rounded-xl bg-[#ffc439] hover:bg-[#f6bb32] text-[#003087] text-xs font-black transition-all text-center shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0 ring-2 ring-amber-400/50"
                  >
                    <span className="font-extrabold italic text-base text-[#003087]">Pay</span><span className="font-extrabold italic text-base text-[#0079c1]">Pal</span>
                    <span className="border-l border-[#003087]/30 pl-2 font-bold text-xs text-[#003087]">Pay $97 with PayPal</span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#003087]" />
                  </a>
                  <p className="text-[10px] text-center text-amber-300/80 font-semibold">
                    ⭐ Instant Automated Key & Full Access Delivered
                  </p>
                </div>
              </div>

              {/* Tier 3: Lifetime Founder */}
              <div className="bg-[#0f172a] p-5 rounded-xl border border-[#334155] flex flex-col justify-between space-y-4">
                <div>
                  <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">
                    Founder Lifetime Pass
                  </span>
                  <div className="text-3xl font-extrabold text-white mt-1 mb-2">
                    $197<span className="text-xs text-[#94a3b8] font-normal"> one-time lifetime</span>
                  </div>
                  <p className="text-xs text-[#94a3b8]">
                    Pay once, own Cash Captain Marketeer forever with all future AI engine updates.
                  </p>
                  <ul className="text-xs text-slate-300 space-y-2 mt-4">
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span>Lifetime Software Ownership</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span>All Future AI Engine Upgrades</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span>Priority Support from Founder</span>
                    </li>
                  </ul>
                </div>

                <div className="space-y-2 pt-2">
                  <a
                    href={PAYPAL_LIFETIME_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                      sendPurchaseAlertToOwner({
                        tierName: 'Founder Lifetime Pass ($197)',
                        amount: 197,
                        timestamp: new Date().toLocaleString()
                      });
                    }}
                    className="w-full py-3 px-4 rounded-xl bg-[#ffc439] hover:bg-[#f6bb32] text-[#003087] text-xs font-black transition-all text-center flex items-center justify-center gap-2 shadow-md hover:shadow-lg cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
                  >
                    <span className="font-extrabold italic text-sm text-[#003087]">Pay</span><span className="font-extrabold italic text-sm text-[#0079c1]">Pal</span>
                    <span className="border-l border-[#003087]/30 pl-2 font-bold text-xs text-[#003087]">Pay $197 Lifetime via PayPal</span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#003087]" />
                  </a>
                  <p className="text-[10px] text-center text-slate-400">
                    🔒 Official PayPal Checkout &bull; Zero Recurring Fees
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PUBLIC SALES PAGE PREVIEW */}
      {activeTab === 'preview' && (
        <div className="bg-gradient-to-b from-[#1e293b] via-[#0f172a] to-[#0f172a] p-8 rounded-2xl border border-amber-500/40 shadow-2xl space-y-8 text-center max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 text-amber-300 text-xs font-bold border border-amber-500/30">
            <span>⚔️ Created & Founded by Ty Birchfield &bull; "All for Cash, and Cash for All!"</span>
          </div>

          <div className="space-y-4">
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              Turn 1 Affiliate Link Into A 24/7 Buyer Army.
            </h1>
            <p className="text-sm sm:text-lg text-[#94a3b8] max-w-2xl mx-auto leading-relaxed">
              <strong>Cash Captain Marketeer</strong> is the autonomous AI agent that scrapes the web, finds people actively begging to buy your products, and auto-places your links on 100% autopilot.
            </p>
          </div>

          {/* Quick Tier Toggle for Checkout Link */}
          <div className="inline-flex p-1 rounded-xl bg-[#0f172a] border border-[#334155] gap-1">
            <button
              onClick={() => setPreviewSelectedTier('starter')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                previewSelectedTier === 'starter'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Starter ($47)
            </button>
            <button
              onClick={() => setPreviewSelectedTier('pro')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                previewSelectedTier === 'pro'
                  ? 'bg-amber-500 text-slate-950 font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Captain Pro ($97)
            </button>
            <button
              onClick={() => setPreviewSelectedTier('lifetime')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                previewSelectedTier === 'lifetime'
                  ? 'bg-purple-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Lifetime Pass ($197)
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <a
              href={
                previewSelectedTier === 'starter'
                  ? PAYPAL_STARTER_URL
                  : previewSelectedTier === 'pro'
                  ? PAYPAL_PRO_URL
                  : PAYPAL_LIFETIME_URL
              }
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => {
                const amt = previewSelectedTier === 'starter' ? 47 : previewSelectedTier === 'pro' ? 97 : 197;
                const name =
                  previewSelectedTier === 'starter'
                    ? 'Starter Marketeer ($47)'
                    : previewSelectedTier === 'pro'
                    ? 'Captain Pro License ($97)'
                    : 'Founder Lifetime Pass ($197)';
                sendPurchaseAlertToOwner({
                  tierName: name,
                  amount: amt,
                  timestamp: new Date().toLocaleString()
                });
              }}
              className="py-3.5 px-8 rounded-xl bg-[#ffc439] hover:bg-[#f6bb32] text-[#003087] font-black text-base transition-all shadow-xl shadow-amber-500/25 active:scale-95 flex items-center gap-2.5 cursor-pointer ring-2 ring-amber-400/40"
            >
              <span className="font-extrabold italic text-lg text-[#003087]">Pay</span><span className="font-extrabold italic text-lg text-[#0079c1]">Pal</span>
              <span className="border-l border-[#003087]/30 pl-2 font-bold text-sm text-[#003087]">
                Claim {previewSelectedTier === 'starter' ? 'Starter ($47)' : previewSelectedTier === 'pro' ? 'Captain Pro ($97)' : 'Lifetime Pass ($197)'} via PayPal
              </span>
              <ExternalLink className="w-4 h-4 text-[#003087]" />
            </a>
          </div>

          <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
            <span>🔒 100% Encrypted &amp; Secure Direct PayPal Checkout &bull; Instant Software License Delivery</span>
          </p>

          {/* Mobile Radar App Showcase */}
          <div className="pt-4 flex flex-col items-center">
            <div className="max-w-md w-full rounded-2xl overflow-hidden border border-amber-500/30 shadow-2xl bg-[#0f172a] p-3 text-center">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-2">
                📱 Real-Time Radar In Your Pocket
              </span>
              <img
                src="/assets/aistudio/image_595560ec-d709-4c7b-b653-df9c2d72a30e_b5b28fc5.jpg"
                alt="Cash Captain Marketeer Mobile Radar and Analytics"
                className="max-h-[320px] w-auto mx-auto object-contain rounded-xl shadow-lg border border-[#334155]"
              />
              <span className="text-[11px] text-slate-400 mt-2 block">
                Track buyer leads, traffic overview, and ROI anytime from anywhere.
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8 border-t border-[#334155]/60 text-left">
            <div className="p-4 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
              <span className="text-2xl mb-1 block">🕵️</span>
              <h4 className="text-sm font-bold text-white mb-1">Autonomous Scraping</h4>
              <p className="text-xs text-[#94a3b8]">
                Finds exact live discussions on Reddit, Quora, and forums where buyers are asking questions.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
              <span className="text-2xl mb-1 block">🛡️</span>
              <h4 className="text-sm font-bold text-white mb-1">Zero-Ban Guarantee</h4>
              <p className="text-xs text-[#94a3b8]">
                Writes helpful problem-solving responses so your links survive moderation and rank organically.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#1e293b]/70 border border-[#334155]">
              <span className="text-2xl mb-1 block">⚡</span>
              <h4 className="text-sm font-bold text-white mb-1">Hands-Free Dispatch</h4>
              <p className="text-xs text-[#94a3b8]">
                No tedious tab hopping. The engine executes and verifies your placements in the background.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
