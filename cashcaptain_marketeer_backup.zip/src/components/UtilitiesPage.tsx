import React from 'react';
import {
  Download,
  BookOpen,
  UploadCloud,
  RefreshCw,
  Flame,
  ShieldCheck,
  HardDrive,
  Database,
  Cpu,
  Layers,
  Sparkles,
  FileArchive
} from 'lucide-react';
import { Offer, TrackingMetrics } from '../types';

interface UtilitiesPageProps {
  offers: Offer[];
  tracking: TrackingMetrics;
  isBuilding: boolean;
  onRebuild: () => void;
  onOpenBulkAdd: () => void;
  onOpenUserGuide: () => void;
  onOpenFirebaseGuide: () => void;
}

export const UtilitiesPage: React.FC<UtilitiesPageProps> = ({
  offers,
  tracking,
  isBuilding,
  onRebuild,
  onOpenBulkAdd,
  onOpenUserGuide,
  onOpenFirebaseGuide
}) => {
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-[#1e293b] to-slate-900 p-6 rounded-2xl border border-slate-700/80 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shadow">
            🛠️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">System Utilities & Tools</h1>
              <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-xs font-mono font-bold border border-slate-700">
                Admin Suite
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#94a3b8]">
              Centralized controls for system backups, bulk imports, user manuals, and cloud synchronization.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-[#0f172a] px-3 py-2 rounded-xl border border-slate-800 text-xs text-slate-300 font-mono">
          <Database className="w-4 h-4 text-emerald-400" />
          <span>Active Offers: <strong className="text-white">{offers.length}</strong></span>
        </div>
      </div>

      {/* Grid of Utilities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* CARD 1: Full System Backup */}
        <div className="bg-[#1e293b] rounded-xl p-5 border border-cyan-500/30 shadow-lg space-y-3.5 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-lg bg-cyan-500/15 text-cyan-400 flex items-center justify-center">
                <FileArchive className="w-5 h-5" />
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/50">
                Full Project ZIP
              </span>
            </div>
            <h3 className="text-base font-bold text-white">Complete System & Data Backup</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Download the complete self-contained archive containing all application code, marketing templates, buyer radar configs, and data assets.
            </p>
          </div>

          <div className="pt-2">
            <a
              href="/cashcaptain_marketeer_backup.zip"
              download="cashcaptain_marketeer_backup.zip"
              className="w-full py-2.5 px-4 rounded-lg font-bold text-xs bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Download Backup (.ZIP Archive)</span>
            </a>
          </div>
        </div>

        {/* CARD 2: User Manual & Operating Guide */}
        <div className="bg-[#1e293b] rounded-xl p-5 border border-amber-500/30 shadow-lg space-y-3.5 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center">
                <BookOpen className="w-5 h-5" />
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/50">
                Documentation
              </span>
            </div>
            <h3 className="text-base font-bold text-white">User Manual & Operating Guide</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Step-by-step operating documentation covering affiliate links, autonomous ad placement, zero-ban compliance, and lead tracking.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={onOpenUserGuide}
              className="w-full py-2.5 px-4 rounded-lg font-bold text-xs bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Open Complete User Manual</span>
            </button>
          </div>
        </div>

        {/* CARD 3: Bulk Offer Import */}
        <div className="bg-[#1e293b] rounded-xl p-5 border border-blue-500/30 shadow-lg space-y-3.5 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-lg bg-blue-500/15 text-blue-400 flex items-center justify-center">
                <UploadCloud className="w-5 h-5" />
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800/50">
                Bulk Tools
              </span>
            </div>
            <h3 className="text-base font-bold text-white">Bulk Offer Importer</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Import multiple affiliate products simultaneously via CSV, JSON, or formatted text lines to quickly populate your database.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={onOpenBulkAdd}
              className="w-full py-2.5 px-4 rounded-lg font-bold text-xs bg-blue-600 hover:bg-blue-500 text-white transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Launch Bulk Importer</span>
            </button>
          </div>
        </div>

        {/* CARD 4: Pipeline Sync & Rebuild */}
        <div className="bg-[#1e293b] rounded-xl p-5 border border-emerald-500/30 shadow-lg space-y-3.5 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
                <RefreshCw className="w-5 h-5" />
              </span>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800/50">
                Pipeline
              </span>
            </div>
            <h3 className="text-base font-bold text-white">Sync All Search Tools & Hubs</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Regenerate all micro-search widget files, directory indices, and tracking links across your active catalog.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={onRebuild}
              disabled={isBuilding}
              className={`w-full py-2.5 px-4 rounded-lg font-bold text-xs text-white transition-all flex items-center justify-center gap-2 shadow-sm ${
                isBuilding
                  ? 'bg-slate-700 cursor-not-allowed text-slate-400'
                  : 'bg-emerald-600 hover:bg-emerald-500 cursor-pointer'
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${isBuilding ? 'animate-spin' : ''}`} />
              <span>{isBuilding ? 'Syncing...' : 'Sync All Assets Now'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Cloud Integration Status Card */}
      <div className="bg-[#1e293b] p-5 rounded-xl border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-orange-500/15 text-orange-400 flex items-center justify-center shrink-0">
            <Flame className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Firebase Cloud Firestore & Authentication</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Connected
              </span>
            </h4>
            <p className="text-xs text-slate-400">
              Live multi-device database synchronization, security rules, and real-time tracking data.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenFirebaseGuide}
          className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition cursor-pointer shrink-0"
        >
          View Cloud Credentials
        </button>
      </div>
    </div>
  );
};
