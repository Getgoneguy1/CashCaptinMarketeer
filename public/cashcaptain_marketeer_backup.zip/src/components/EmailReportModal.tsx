import React, { useState, useEffect } from 'react';
import {
  Mail,
  CheckCircle2,
  AlertCircle,
  Clock,
  Send,
  Sparkles,
  Shield,
  Smartphone,
  DollarSign,
  TrendingUp,
  Settings,
  Eye,
  X,
  RefreshCw,
  Bell
} from 'lucide-react';
import { Offer, TrackingMetrics, BuyerLead } from '../types';
import {
  EmailReportConfig,
  getStoredEmailConfig,
  saveEmailConfig,
  dispatchEmailReport,
  sendPurchaseAlertToOwner,
  getStoredSalesAlerts,
  buildUserReport,
  OWNER_NOTIFICATION_EMAIL,
  OWNER_PAYPAL_EMAIL,
  PurchaseAlertRecord
} from '../services/emailReportService';

interface EmailReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracking: TrackingMetrics;
  offers: Offer[];
  leads: BuyerLead[];
}

export const EmailReportModal: React.FC<EmailReportModalProps> = ({
  isOpen,
  onClose,
  tracking,
  offers,
  leads
}) => {
  const [config, setConfig] = useState<EmailReportConfig>(getStoredEmailConfig());
  const [activeSubTab, setActiveSubTab] = useState<'weekly' | 'sales_alerts' | 'mobile_view' | 'emailjs'>('weekly');
  const [isSending, setIsSending] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [salesAlerts, setSalesAlerts] = useState<PurchaseAlertRecord[]>([]);

  useEffect(() => {
    if (isOpen) {
      setConfig(getStoredEmailConfig());
      setSalesAlerts(getStoredSalesAlerts());
      setStatusMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveConfig = () => {
    saveEmailConfig(config);
    setStatusMessage({ type: 'success', text: 'Email reporting preferences saved successfully!' });
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const handleSendWeeklyNow = async () => {
    setIsSending(true);
    setStatusMessage(null);
    try {
      const res = await dispatchEmailReport(config, tracking, offers, leads);
      setConfig(getStoredEmailConfig());
      setStatusMessage({
        type: 'success',
        text: res.message
      });
    } catch (e: any) {
      setStatusMessage({
        type: 'error',
        text: 'Failed to dispatch email briefing. Please verify your connection.'
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleSimulatePurchaseAlert = async (tier: 'starter' | 'pro' | 'lifetime') => {
    setIsSending(true);
    setStatusMessage(null);
    const tierMap = {
      starter: { name: 'Starter Marketeer ($47)' as const, amount: 47 },
      pro: { name: 'Captain Pro License ($97)' as const, amount: 97 },
      lifetime: { name: 'Founder Lifetime Pass ($197)' as const, amount: 197 }
    };
    const selected = tierMap[tier];

    try {
      const res = await sendPurchaseAlertToOwner({
        tierName: selected.name,
        amount: selected.amount,
        buyerName: 'Alex Turner',
        buyerEmail: 'alex.turner@digitalventures.com',
        timestamp: new Date().toLocaleString()
      });
      setSalesAlerts(getStoredSalesAlerts());
      setStatusMessage({
        type: 'success',
        text: `💰 Sale Alert Triggered: ${res.message}`
      });
    } catch (e) {
      setStatusMessage({
        type: 'error',
        text: 'Failed to record purchase alert.'
      });
    } finally {
      setIsSending(false);
    }
  };

  const currentReport = buildUserReport(tracking, offers, leads, config.recipientEmail);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#1e293b] border border-[#334155] rounded-2xl max-w-3xl w-full p-6 shadow-2xl relative my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-[#334155]">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 flex items-center justify-center font-black shadow-md shadow-amber-500/20">
            📬
          </div>
          <div>
            <h2 className="text-xl font-black text-white">
              Automated Email Reports & Purchase Alerts
            </h2>
            <p className="text-xs text-[#94a3b8]">
              Powered by Public Email API (EmailJS) &bull; Weekly Dashboard Briefings & Instant Sales Notifications
            </p>
          </div>
        </div>

        {/* Status Toast */}
        {statusMessage && (
          <div
            className={`mt-4 p-3 rounded-lg text-xs font-semibold flex items-center gap-2 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-950/70 border border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/70 border border-rose-500/40 text-rose-300'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Sub Navigation */}
        <div className="flex items-center gap-2 mt-4 pb-2 border-b border-[#334155]/60 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('weekly')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeSubTab === 'weekly'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-[#0f172a] text-slate-300 hover:text-white border border-[#334155]'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Weekly Traffic & Lead Briefing</span>
          </button>

          <button
            onClick={() => setActiveSubTab('sales_alerts')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeSubTab === 'sales_alerts'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-[#0f172a] text-slate-300 hover:text-white border border-[#334155]'
            }`}
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span>💰 App Purchase Alerts ({OWNER_NOTIFICATION_EMAIL})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('mobile_view')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeSubTab === 'mobile_view'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-[#0f172a] text-slate-300 hover:text-white border border-[#334155]'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-blue-400" />
            <span>📱 Mobile Radar View</span>
          </button>

          <button
            onClick={() => setActiveSubTab('emailjs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
              activeSubTab === 'emailjs'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'bg-[#0f172a] text-slate-300 hover:text-white border border-[#334155]'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>API Settings (EmailJS)</span>
          </button>
        </div>

        {/* TAB 1: WEEKLY TRAFFIC & LEAD BRIEFING */}
        {activeSubTab === 'weekly' && (
          <div className="space-y-5 mt-4">
            {/* Privacy Guarantee Banner */}
            <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-xl text-xs text-blue-200 flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold">Strict Privacy Isolation:</strong>
                Each user receives emails solely regarding their <em>own</em> personal traffic, clicks, and radar leads. No other user's campaign data is ever shared or sent.
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Recipient Email Address
                </label>
                <input
                  type="email"
                  value={config.recipientEmail}
                  onChange={(e) => setConfig({ ...config, recipientEmail: e.target.value })}
                  placeholder="e.g. tybirchfield2@gmail.com"
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Your weekly dashboard report will be dispatched here.
                </span>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Automated Dispatch Frequency
                </label>
                <select
                  value={config.frequency}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      frequency: e.target.value as 'weekly' | 'daily' | 'disabled'
                    })
                  }
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="weekly">Weekly (Every 7 Days — Recommended)</option>
                  <option value="daily">Daily Briefing</option>
                  <option value="disabled">Disabled (Manual Only)</option>
                </select>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Next scheduled run:{' '}
                  <strong className="text-amber-400">
                    {config.nextScheduledAt
                      ? new Date(config.nextScheduledAt).toLocaleDateString()
                      : 'Scheduled on activation'}
                  </strong>
                </span>
              </div>
            </div>

            {/* Quick Metrics Snapshot */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#0f172a] p-3 rounded-lg border border-[#334155]">
                <span className="text-[10px] text-slate-400 uppercase font-bold">Tracked Clicks</span>
                <div className="text-base font-black text-sky-400">{tracking.clicks || 0}</div>
              </div>
              <div className="bg-[#0f172a] p-3 rounded-lg border border-[#334155]">
                <span className="text-[10px] text-slate-400 uppercase font-bold">Conversions</span>
                <div className="text-base font-black text-emerald-400">{tracking.conversions || 0}</div>
              </div>
              <div className="bg-[#0f172a] p-3 rounded-lg border border-[#334155]">
                <span className="text-[10px] text-slate-400 uppercase font-bold">Tracked Revenue</span>
                <div className="text-base font-black text-amber-400">${(tracking.revenue || 0).toFixed(2)}</div>
              </div>
              <div className="bg-[#0f172a] p-3 rounded-lg border border-[#334155]">
                <span className="text-[10px] text-slate-400 uppercase font-bold">Active Radar Leads</span>
                <div className="text-base font-black text-purple-400">{leads.length}</div>
              </div>
            </div>

            {/* Live Report Preview Box */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Live Email Content Preview (What gets sent to {config.recipientEmail}):</span>
              </span>
              <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] text-xs font-mono text-slate-300 max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                {currentReport.summaryText}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <button
                onClick={handleSaveConfig}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-[#334155] cursor-pointer"
              >
                Save Preferences
              </button>

              <button
                onClick={handleSendWeeklyNow}
                disabled={isSending}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:opacity-95 text-slate-950 text-xs font-black transition shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSending ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
                <span>{isSending ? 'Dispatching...' : 'Send Weekly Report Now (Test Run)'}</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: INSTANT APP PURCHASE ALERTS */}
        {activeSubTab === 'sales_alerts' && (
          <div className="space-y-5 mt-4">
            <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs text-emerald-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-white text-sm">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Instant App Purchase Notifications For Ty Birchfield</span>
              </div>
              <p>
                Whenever someone purchases a license for Cash Captain Marketeer on the web, an instant email alert is automatically dispatched to <strong className="text-emerald-300 underline">{OWNER_NOTIFICATION_EMAIL}</strong> with the purchase tier, amount ($47, $97, or $197), and buyer information.
              </p>
            </div>

            {/* Test Simulation Controls */}
            <div className="bg-[#0f172a] p-4 rounded-xl border border-[#334155] space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                🧪 Test Live Sale Alert Dispatch to {OWNER_NOTIFICATION_EMAIL}
              </h4>
              <p className="text-xs text-[#94a3b8]">
                Click any package below to simulate a live customer purchase and send the alert:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                <button
                  onClick={() => handleSimulatePurchaseAlert('starter')}
                  disabled={isSending}
                  className="p-3 rounded-lg bg-[#1e293b] hover:bg-slate-700 border border-[#334155] text-left transition cursor-pointer"
                >
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Starter Tier</span>
                  <div className="text-sm font-black text-white">$47.00 Sale</div>
                  <span className="text-[11px] text-emerald-400 mt-1 block">Trigger Alert &rarr;</span>
                </button>

                <button
                  onClick={() => handleSimulatePurchaseAlert('pro')}
                  disabled={isSending}
                  className="p-3 rounded-lg bg-gradient-to-b from-[#1e293b] to-amber-950/40 hover:border-amber-500 border border-amber-500/40 text-left transition cursor-pointer"
                >
                  <span className="text-[10px] text-amber-400 uppercase font-bold block">Captain Pro</span>
                  <div className="text-sm font-black text-white">$97.00 Sale</div>
                  <span className="text-[11px] text-amber-300 mt-1 block">Trigger Alert &rarr;</span>
                </button>

                <button
                  onClick={() => handleSimulatePurchaseAlert('lifetime')}
                  disabled={isSending}
                  className="p-3 rounded-lg bg-[#1e293b] hover:bg-slate-700 border border-[#334155] text-left transition cursor-pointer"
                >
                  <span className="text-[10px] text-purple-400 uppercase font-bold block">Founder Lifetime</span>
                  <div className="text-sm font-black text-white">$197.00 Sale</div>
                  <span className="text-[11px] text-purple-300 mt-1 block">Trigger Alert &rarr;</span>
                </button>
              </div>
            </div>

            {/* Recent Sales Alerts Log */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300">
                Recent Purchase Alerts Dispatched to {OWNER_NOTIFICATION_EMAIL} ({salesAlerts.length})
              </h4>
              <div className="bg-[#0f172a] rounded-xl border border-[#334155] max-h-44 overflow-y-auto divide-y divide-[#334155]">
                {salesAlerts.length > 0 ? (
                  salesAlerts.map((alert) => (
                    <div key={alert.id} className="p-3 text-xs flex items-center justify-between gap-2">
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{alert.tierName}</span>
                          <span className="text-emerald-400 font-mono font-bold">+${alert.amount}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Buyer: {alert.buyerName} &bull; TX: {alert.transactionId} &bull; Key: {alert.licenseKey}
                        </div>
                      </div>
                      <div className="text-right text-[11px] text-slate-400">
                        <div>{alert.timestamp}</div>
                        <span className="text-[10px] text-emerald-400 font-bold uppercase">Delivered</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-slate-500">
                    No purchase alerts recorded yet. Click above to test a simulated sale alert.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: MOBILE RADAR & ANALYTICS VIEW */}
        {activeSubTab === 'mobile_view' && (
          <div className="space-y-4 mt-4 text-center">
            <div className="p-3 bg-[#0f172a] border border-[#334155] rounded-xl text-xs text-slate-300">
              <span className="text-amber-400 font-bold">📱 Cash Captain Marketeer Mobile Radar Interface:</span> Real-time buyer radar scanning, 789 active leads, live traffic overview, and 280% ROI tracking in your pocket.
            </div>

            <div className="relative rounded-2xl overflow-hidden border-2 border-amber-500/40 shadow-2xl bg-slate-950 flex items-center justify-center p-2">
              <img
                src="/assets/aistudio/image_595560ec-d709-4c7b-b653-df9c2d72a30e_b5b28fc5.jpg"
                alt="Cash Captain Marketeer Mobile Radar and Live Analytics"
                className="max-h-[380px] w-auto object-contain rounded-xl shadow-lg"
              />
            </div>

            <p className="text-xs text-[#94a3b8]">
              Automated Marketing Radar scans 24/7. When buyer threads appear, Cash Captain Marketeer dispatches the tailored ad copy instantly.
            </p>
          </div>
        )}

        {/* TAB 4: EMAILJS API SETTINGS */}
        {activeSubTab === 'emailjs' && (
          <div className="space-y-4 mt-4">
            <div className="p-3 bg-purple-950/40 border border-purple-500/30 rounded-xl text-xs text-purple-200">
              <strong className="text-white block font-semibold">Public Email API Integration:</strong>
              Cash Captain Marketeer uses EmailJS to dispatch reports directly from the web application without requiring a dedicated SMTP server. You can use our verified default relay, or plug in your own free EmailJS credentials below:
            </div>

            <div className="space-y-3 bg-[#0f172a] p-4 rounded-xl border border-[#334155]">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  EmailJS Service ID
                </label>
                <input
                  type="text"
                  value={config.emailjsServiceId}
                  onChange={(e) => setConfig({ ...config, emailjsServiceId: e.target.value })}
                  placeholder="e.g. service_gmail or service_cashcaptain"
                  className="w-full bg-[#1e293b] border border-[#334155] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  EmailJS Template ID
                </label>
                <input
                  type="text"
                  value={config.emailjsTemplateId}
                  onChange={(e) => setConfig({ ...config, emailjsTemplateId: e.target.value })}
                  placeholder="e.g. template_weekly_briefing"
                  className="w-full bg-[#1e293b] border border-[#334155] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  EmailJS Public Key
                </label>
                <input
                  type="text"
                  value={config.emailjsPublicKey}
                  onChange={(e) => setConfig({ ...config, emailjsPublicKey: e.target.value })}
                  placeholder="e.g. your_emailjs_public_api_key"
                  className="w-full bg-[#1e293b] border border-[#334155] rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div className="pt-2 text-[11px] text-slate-400">
                Template variables passed automatically:{' '}
                <code className="text-amber-300">to_email</code>,{' '}
                <code className="text-amber-300">subject</code>,{' '}
                <code className="text-amber-300">message</code>,{' '}
                <code className="text-amber-300">total_clicks</code>,{' '}
                <code className="text-amber-300">total_revenue</code>,{' '}
                <code className="text-amber-300">high_intent_leads</code>.
              </div>
            </div>

            <button
              onClick={handleSaveConfig}
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition cursor-pointer"
            >
              Save EmailJS Credentials
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
