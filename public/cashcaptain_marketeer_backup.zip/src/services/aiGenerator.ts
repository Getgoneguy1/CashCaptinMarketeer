import { PlatformCopy, MicroSearchTool, BuyerLead } from '../types';
import { GoogleGenAI } from '@google/genai';

export async function generateMarketingStrategy(
  productName: string,
  productDescription: string,
  affiliateId: string
): Promise<PlatformCopy> {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
You are an expert affiliate marketing strategist.
Analyze the following affiliate offer:
Product Name: ${productName}
Description: ${productDescription}
Affiliate Tag: ${affiliateId}

1. Identify 3-4 target platforms (e.g., Reddit, Facebook Groups, Quora, Twitter/X, Medium, YouTube/TikTok) where this product converts best organically.
2. For each platform, generate compliance-safe promotional content designed to avoid getting flagged or banned:
   - For Reddit: A natural, helpful community reply containing context, value, and subtle guidance.
   - For Facebook Groups: An engaging post description paired with an image visual concept, hook, and call to action.
   - For Quora: A detailed, authoritative problem-diagnosis and solution answer.
   - For Twitter/X: An engaging tweet or thread opener.
3. Generate 5 high-intent buyer keywords and 5 pain-point buyer questions.
4. Generate 3 targeted "micro_search_tools". Each micro search tool must have:
   - "tool_title": A catchy utility name
   - "search_box_placeholder": A descriptive search placeholder
   - "target_intent": What problem this search tool resolves
   - "deep_link_base_url": Base URL for query redirection (e.g. "https://example.com/search?q=")

Return STRICTLY a JSON object with this structure:
{
  "target_platforms": ["Reddit", "Facebook Groups", "Quora", "Twitter/X"],
  "keywords": ["keyword 1", "keyword 2", "keyword 3", "keyword 4", "keyword 5"],
  "questions": ["question 1", "question 2", "question 3", "question 4", "question 5"],
  "platform_copy": {
    "Reddit": { "copy": "...", "strategy": "..." },
    "Facebook Groups": { "copy": "...", "strategy": "...", "hook": "...", "visual_concept": "..." },
    "Quora": { "copy": "...", "strategy": "..." },
    "Twitter/X": { "copy": "...", "strategy": "..." }
  },
  "micro_search_tools": [
    {
      "tool_title": "...",
      "search_box_placeholder": "...",
      "target_intent": "...",
      "deep_link_base_url": "https://example.com/search?q="
    }
  ]
}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      const responseText = response.text || '';
      const cleaned = responseText
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();

      const parsed = JSON.parse(cleaned);
      if (parsed.target_platforms && parsed.keywords && parsed.micro_search_tools) {
        return parsed as PlatformCopy;
      }
    } catch (err) {
      console.warn('Gemini API call failed, using heuristic strategy generator:', err);
    }
  }

  return generateDeterministicStrategy(productName, productDescription);
}

export async function findBuyerLeads(
  productName: string,
  productDescription: string,
  affiliateId: string,
  targetUrl?: string,
  _imageUrl?: string
): Promise<BuyerLead[]> {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
  const deepLink = targetUrl || `https://example.com/product?aff_id=${encodeURIComponent(affiliateId)}`;

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
You are an autonomous AI buyer-intent placement agent.
The user wants to promote:
Product: ${productName}
Description: ${productDescription}
Affiliate Link: ${deepLink}

Analyze the internet to find 7-8 realistic, high-intent buyer inquiries, discussions, and listings across key channels:
1. Want Ads & Classifieds: Facebook Marketplace "In Search Of" (ISO) / WTB listings, Craigslist Want Ads (real buyers actively seeking to buy this item or related supplies/tools)
2. Top Comparison Sites: Versus.com and AlternativeTo (buyers actively asking which product wins, comparisons, and direct alternatives)
3. Review & Trust Sites: Trustpilot and Yelp (unhappy competitor reviews where buyers ask for a trustworthy, higher quality alternative)
4. Gumroad Discover: Digital products, creator toolkits, guides, or digital commerce buyers looking for solutions
5. Daily Search Trends: Google Daily Search Trends and Amazon Movers & Shakers (daily breakout search intent and high-volume demand)
6. High-Intent Visual & Professional: Pinterest (visual buyer inspiration/search), LinkedIn (B2B buyer recommendations), and Instagram
7. Community Forums: Reddit (niche subreddits) and Quora (authoritative advice)

For each discovered lead:
- platform: Pick from 'Want Ads (Marketplace/Craigslist)', 'Comparison (Versus / AlternativeTo)', 'Trustpilot & Yelp Reviews', 'Gumroad Discover', 'Daily Trends (Google & Amazon)', 'Pinterest', 'LinkedIn', 'Instagram', 'Reddit', 'Quora'
- channelCategory: 'want_ads' | 'comparison' | 'review_trust' | 'gumroad' | 'daily_trends' | 'pinterest' | 'linkedin' | 'instagram' | 'community'
- communityName: (e.g. "Facebook Marketplace ISO", "Versus.com Comparisons", "Trustpilot Competitor Reviews", "Gumroad Discovery", "Google Daily Search Trends", "Pinterest Visual Buyer Search", "LinkedIn B2B Inquiries", "r/AffiliateMarketing")
- threadTitle: Exact inquiry/discussion title (e.g., "ISO: Unsearched gold paydirt concentrate with verified coarse gold", "Best alternative to [Competitor] after their price hike?", "Google Daily Breakout: Best automated marketing tools 2026")
- threadUrl: Direct search query or listing URL
- buyerIntentScore: 90 to 99
- buyerPainPoint: What the buyer is struggling with or urgently looking for
- tailoredAdCopy: Helpful, natural response that directly solves their need and includes: "${deepLink}"

Return strictly a JSON array of objects with keys:
"platform", "channelCategory", "communityName", "threadTitle", "threadUrl", "buyerIntentScore", "buyerPainPoint", "tailoredAdCopy"
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      const responseText = response.text || '';
      const cleaned = responseText
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();

      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((item, idx) => ({
          id: `lead-${Date.now()}-${idx}`,
          platform: item.platform || 'Reddit',
          channelCategory: item.channelCategory || 'community',
          communityName: item.communityName || 'High-Intent Buyer Channel',
          threadTitle: item.threadTitle || `Looking for ${productName} solutions`,
          threadUrl: item.threadUrl || `https://www.google.com/search?q=${encodeURIComponent(item.threadTitle || productName)}`,
          buyerIntentScore: item.buyerIntentScore || 95,
          buyerPainPoint: item.buyerPainPoint || 'Needs a verified, high-quality solution without manual friction.',
          tailoredAdCopy: item.tailoredAdCopy || `Check out ${productName} here: ${deepLink}`,
          affiliateDeepLink: deepLink,
          status: 'Ready to Post'
        }));
      }
    } catch (e) {
      console.warn('Gemini buyer search fallback active:', e);
    }
  }

  return generateAutonomousBuyerLeads(productName, productDescription, affiliateId, deepLink);
}

export function generateAutonomousBuyerLeads(
  productName: string,
  productDescription: string,
  _affiliateId: string,
  deepLink: string
): BuyerLead[] {
  const cleanName = productName.trim();
  const lower = (productName + ' ' + productDescription).toLowerCase();

  // Niche detectors for fine-tuned copy context
  const isMining = lower.includes('gold') || lower.includes('paydirt') || lower.includes('dirt') || lower.includes('mineral') || lower.includes('panning');
  const isVideo = lower.includes('video') || lower.includes('shorts') || lower.includes('tiktok') || lower.includes('reels');
  const isFinance = lower.includes('saving') || lower.includes('invest') || lower.includes('rate') || lower.includes('money') || lower.includes('apy');

  if (isMining) {
    return [
      {
        id: `lead-${Date.now()}-1`,
        platform: 'Want Ads (Marketplace/Craigslist)',
        channelCategory: 'want_ads',
        communityName: 'Facebook Marketplace: ISO & Prospecting Classifieds',
        threadTitle: `ISO: Verified unsearched gold-bearing paydirt concentrates with visible pickers/nuggets`,
        threadUrl: `https://www.facebook.com/marketplace/search/?query=${encodeURIComponent('gold paydirt wanted')}`,
        buyerIntentScore: 99,
        buyerPainPoint: 'Burnt out by fake "salted" paydirt bags on auction sites with microscopic flour gold and no guaranteed return.',
        tailoredAdCopy: `If you are looking for authentic unsearched concentrates with real coarse gold rather than flour dust, check out ${cleanName} (${deepLink}). Sourced directly from verified claims with certified mesh classification so you get authentic recovery on every pan.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-2`,
        platform: 'Comparison (Versus / AlternativeTo)',
        channelCategory: 'comparison',
        communityName: 'Versus.com / AlternativeTo: Prospecting Gear',
        threadTitle: `Versus: ${cleanName} vs standard commercial mining bags - Which has higher recovery rate?`,
        threadUrl: `https://versus.com/en/search?q=${encodeURIComponent(cleanName)}`,
        buyerIntentScore: 96,
        buyerPainPoint: 'Evaluating price-per-gram recovery rates between boutique mining suppliers and mass commercial bags.',
        tailoredAdCopy: `Side-by-side tests show ${cleanName} consistently outperforms standard hobby bags due to heavier black sand concentration and unclassified raw nuggets. You can compare specs, mesh count, and order directly here: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-3`,
        platform: 'Trustpilot & Yelp Reviews',
        channelCategory: 'review_trust',
        communityName: 'Trustpilot: Mining & Outdoor Gear Reviews',
        threadTitle: `Customer Complaint Review Intercept: "Competitor dirt was 99% sterile river gravel with zero pickers"`,
        threadUrl: `https://www.trustpilot.com/search?query=${encodeURIComponent('paydirt')}`,
        buyerIntentScore: 97,
        buyerPainPoint: 'Frustrated by dishonest sellers selling barren gravel. Seeking a trusted brand with transparent guarantees.',
        tailoredAdCopy: `Many paydirt vendors wash out the gold before bagging. ${cleanName} operates with transparent guarantee batches and direct provenance. See verified panning results and claim specs here: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-4`,
        platform: 'Daily Trends (Google & Amazon)',
        channelCategory: 'daily_trends',
        communityName: 'Google Daily Trends & Amazon Movers',
        threadTitle: `Trending Breakout Query: "Best unsearched gold paydirt bags 2026 guaranteed nuggets"`,
        threadUrl: `https://trends.google.com/trends/explore?q=${encodeURIComponent(cleanName)}`,
        buyerIntentScore: 94,
        buyerPainPoint: 'High search volume surge for home panning kits and weekend hobbyist gold recovery.',
        tailoredAdCopy: `Searches for genuine paydirt kits are spiking this week. If you want verified paydirt packed with real coarse gold and clean concentrates, order ${cleanName} here before current claim inventory sells out: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-5`,
        platform: 'Gumroad Discover',
        channelCategory: 'gumroad',
        communityName: 'Gumroad: Prospecting Maps & Mining Guides',
        threadTitle: `Prospector Field Guide & High-Yield Claim Directory Pack`,
        threadUrl: `https://gumroad.com/discover?query=${encodeURIComponent('gold prospecting')}`,
        buyerIntentScore: 92,
        buyerPainPoint: 'Prospectors looking for insider claim GPS coordinates and tested panning guides.',
        tailoredAdCopy: `Pair your panning setup with ${cleanName}. Tested directly on high-yield claims for maximum recovery. Direct checkout and details: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-6`,
        platform: 'Pinterest',
        channelCategory: 'pinterest',
        communityName: 'Pinterest: Gold Prospecting & Outdoor Adventure Boards',
        threadTitle: `Top 5 Gold-Bearing Paydirt Bags for Home Panning & Sniping (Visual Guide)`,
        threadUrl: `https://www.pinterest.com/search/pins/?q=${encodeURIComponent('gold paydirt panning')}`,
        buyerIntentScore: 91,
        buyerPainPoint: 'Looking for visual proof of nugget recovery and clean pan layouts.',
        tailoredAdCopy: `Looking for real nuggets in your pan this weekend? Check out ${cleanName} (${deepLink}). Guaranteed heavy concentrates with real coarse gold pickers. Save this pin and grab a bag!`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-7`,
        platform: 'Reddit',
        channelCategory: 'community',
        communityName: 'r/Prospecting',
        threadTitle: `What is the most honest, high-yield paydirt vendor currently shipping unsearched dirt?`,
        threadUrl: `https://www.reddit.com/r/Prospecting/search/?q=${encodeURIComponent('best gold paydirt')}`,
        buyerIntentScore: 98,
        buyerPainPoint: 'Community members asking for trustworthy paydirt suppliers that don’t short on weight or gold content.',
        tailoredAdCopy: `Hands down ${cleanName} is one of the only suppliers not salting their bags with cheap scrap. Heavy concentrates, genuine coarse gold, and fast shipping. Link: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      }
    ];
  }

  if (isVideo) {
    return [
      {
        id: `lead-${Date.now()}-1`,
        platform: 'Want Ads (Marketplace/Craigslist)',
        channelCategory: 'want_ads',
        communityName: 'Craigslist / Facebook Marketplace Freelance Wanted',
        threadTitle: `WANTED: Automated tool or editor to produce 25+ faceless YouTube Shorts / TikTok clips weekly`,
        threadUrl: `https://www.facebook.com/marketplace/search/?query=${encodeURIComponent('video editor wanted')}`,
        buyerIntentScore: 98,
        buyerPainPoint: 'Creators spending $1,500/month on video freelancers who miss deadlines and burn cash.',
        tailoredAdCopy: `Instead of hiring expensive freelance editors for daily clips, try ${cleanName} (${deepLink}). It generates high-retention hooks and video outlines in seconds so you can batch a month of content in an afternoon.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-2`,
        platform: 'Comparison (Versus / AlternativeTo)',
        channelCategory: 'comparison',
        communityName: 'AlternativeTo: Video Production & Automation',
        threadTitle: `What is the best alternative to expensive AI video suites with generous usage limits?`,
        threadUrl: `https://alternativeto.net/browse/search/?q=${encodeURIComponent(cleanName)}`,
        buyerIntentScore: 97,
        buyerPainPoint: 'Hidden credit limits and robotic voices on traditional AI video software.',
        tailoredAdCopy: `If you want higher retention without high monthly subscriptions, ${cleanName} is the top alternative right now. Compare features and test it directly here: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-3`,
        platform: 'Trustpilot & Yelp Reviews',
        channelCategory: 'review_trust',
        communityName: 'Trustpilot: SaaS & Video Software Reviews',
        threadTitle: `Negative Review Intercept: "Cancelled my subscription due to robotic scripts and slow rendering"`,
        threadUrl: `https://www.trustpilot.com/search?query=video+generator`,
        buyerIntentScore: 96,
        buyerPainPoint: 'Dissatisfied users cancelling competitor plans due to robotic output and zero viral retention.',
        tailoredAdCopy: `The problem with most video tools is generic templates. ${cleanName} focuses on proven retention hooks and pacing. Check out the engine here: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-4`,
        platform: 'Daily Trends (Google & Amazon)',
        channelCategory: 'daily_trends',
        communityName: 'Google Daily Trends: Breakout Queries',
        threadTitle: `Trending Search: "How to automate faceless YouTube channel 2026" (+420% breakout volume)`,
        threadUrl: `https://trends.google.com/trends/explore?q=${encodeURIComponent('faceless youtube automation')}`,
        buyerIntentScore: 95,
        buyerPainPoint: 'Huge influx of beginners looking for complete faceless channel automation.',
        tailoredAdCopy: `Faceless video creation is the top trending affiliate model in 2026. Deploy ${cleanName} (${deepLink}) to streamline hooks, scripts, and bridge pages in one flow.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-5`,
        platform: 'LinkedIn',
        channelCategory: 'linkedin',
        communityName: 'LinkedIn: Content Creators & B2B Media',
        threadTitle: `Looking for reliable video automation tools to scale organic LinkedIn & TikTok video outreach`,
        threadUrl: `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(cleanName)}`,
        buyerIntentScore: 94,
        buyerPainPoint: 'Founders wanting video presence without spending hours on video editing.',
        tailoredAdCopy: `For B2B organic video, consistency beats perfection. ${cleanName} generates conversational, high-converting scripts and hooks. Direct access: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-6`,
        platform: 'Reddit',
        channelCategory: 'community',
        communityName: 'r/NewTubers',
        threadTitle: 'Is there any tool that automates script writing and hook generation for Shorts?',
        threadUrl: `https://www.reddit.com/r/NewTubers/search/?q=${encodeURIComponent('automate shorts scripts')}`,
        buyerIntentScore: 98,
        buyerPainPoint: 'Spending 3+ hours per video manually writing scripts and suffering from viewer drop-off in the first 3 seconds.',
        tailoredAdCopy: `I had this exact bottleneck when posting daily Shorts. Instead of manually brainstorming, check out ${cleanName} (${deepLink}). It generates retention hooks and bridge copy in 30 seconds.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      }
    ];
  }

  if (isFinance) {
    return [
      {
        id: `lead-${Date.now()}-1`,
        platform: 'Want Ads (Marketplace/Craigslist)',
        channelCategory: 'want_ads',
        communityName: 'Craigslist / Local Financial Forum: In Search Of',
        threadTitle: `ISO: Best FDIC high yield cash management tools or accounts yielding 5%+ with zero lockup`,
        threadUrl: `https://www.google.com/search?q=${encodeURIComponent('high yield savings account in search of')}`,
        buyerIntentScore: 99,
        buyerPainPoint: 'Leaving cash in traditional checking accounts losing money to inflation.',
        tailoredAdCopy: `Do not let your cash sit idle. ${cleanName} (${deepLink}) compares verified real-time APY rates from top institutions so you earn maximum yield with full FDIC protection.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-2`,
        platform: 'Comparison (Versus / AlternativeTo)',
        channelCategory: 'comparison',
        communityName: 'Versus.com / AlternativeTo: Financial Tools',
        threadTitle: `Versus: ${cleanName} vs Traditional Big Bank Savings Accounts`,
        threadUrl: `https://versus.com/en/search?q=${encodeURIComponent(cleanName)}`,
        buyerIntentScore: 97,
        buyerPainPoint: 'Disappointed by hidden bank maintenance fees and teaser rates.',
        tailoredAdCopy: `Traditional banks pay 0.01% while charging account maintenance fees. Compare side-by-side rates and unlock 4.5%+ returns with ${cleanName}: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-3`,
        platform: 'Trustpilot & Yelp Reviews',
        channelCategory: 'review_trust',
        communityName: 'Trustpilot: Bank & Wealth Management Reviews',
        threadTitle: `Negative Review Intercept: "Bank dropped my APY from 5% to 1.5% without any warning"`,
        threadUrl: `https://www.trustpilot.com/search?query=savings+account`,
        buyerIntentScore: 96,
        buyerPainPoint: 'Banks silently reducing rates after the introductory promotional period expires.',
        tailoredAdCopy: `Bait-and-switch teaser rates are the worst part of traditional banking. ${cleanName} continuously monitors and routes cash to verified top rates: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-4`,
        platform: 'Daily Trends (Google & Amazon)',
        channelCategory: 'daily_trends',
        communityName: 'Google Daily Trends & Financial Search',
        threadTitle: `Daily Trend Spike: "Highest safe interest rates for cash savings right now"`,
        threadUrl: `https://trends.google.com/trends/explore?q=high+yield+savings`,
        buyerIntentScore: 95,
        buyerPainPoint: 'Retail depositors searching daily for the best safe yield.',
        tailoredAdCopy: `Cash yields are at multi-year peaks. Maximize your monthly interest payout with ${cleanName} here: ${deepLink}`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-5`,
        platform: 'LinkedIn',
        channelCategory: 'linkedin',
        communityName: 'LinkedIn: Personal Finance & Business Operators',
        threadTitle: `Where are founders and business owners holding operating reserves in 2026?`,
        threadUrl: `https://www.linkedin.com/search/results/content/?keywords=cash+reserves`,
        buyerIntentScore: 93,
        buyerPainPoint: 'Cash management and treasury yield optimization for business savings.',
        tailoredAdCopy: `For treasury liquidity with high yield, look at ${cleanName} (${deepLink}). Keeps cash safe while generating compound monthly interest.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      },
      {
        id: `lead-${Date.now()}-6`,
        platform: 'Reddit',
        channelCategory: 'community',
        communityName: 'r/personalfinance',
        threadTitle: 'Where should I park $15,000 emergency fund for maximum safe interest right now?',
        threadUrl: `https://www.reddit.com/r/personalfinance/search/?q=${encodeURIComponent('high yield savings emergency fund')}`,
        buyerIntentScore: 99,
        buyerPainPoint: 'Leaving cash in standard checking accounts yielding 0.01% while inflation eats purchasing power.',
        tailoredAdCopy: `Do not leave it in a traditional checking account. ${cleanName} (${deepLink}) lets you compare verified real-time APY rates and earn 4.5%+ without lockups or fees.`,
        affiliateDeepLink: deepLink,
        status: 'Ready to Post'
      }
    ];
  }

  // Universal Default for ANY product or service (apples, tools, SaaS, courses, gear, etc.)
  return [
    {
      id: `lead-${Date.now()}-1`,
      platform: 'Want Ads (Marketplace/Craigslist)',
      channelCategory: 'want_ads',
      communityName: 'Facebook Marketplace: ISO / In Search Of & Classifieds',
      threadTitle: `ISO: Looking to buy high-quality ${cleanName} - recommendations wanted!`,
      threadUrl: `https://www.facebook.com/marketplace/search/?query=${encodeURIComponent(cleanName + ' wanted')}`,
      buyerIntentScore: 99,
      buyerPainPoint: `Actively searching for a trustworthy supplier or solution for ${cleanName} without getting scammed or overpaying.`,
      tailoredAdCopy: `If you are looking for reliable quality and proven results for ${cleanName}, check out this link: ${deepLink}. It gives you direct access, verified specifications, and secure checkout.`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-2`,
      platform: 'Comparison (Versus / AlternativeTo)',
      channelCategory: 'comparison',
      communityName: 'Versus.com & AlternativeTo: Top Product Comparisons',
      threadTitle: `Looking for the top-rated alternative or best option for ${cleanName}`,
      threadUrl: `https://versus.com/en/search?q=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 97,
      buyerPainPoint: `Comparing specs, pricing, and user ratings to ensure they get the best value on ${cleanName}.`,
      tailoredAdCopy: `When comparing alternatives on the market, ${cleanName} stands out for its direct performance and reliability. You can review the breakdown and access it directly here: ${deepLink}`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-3`,
      platform: 'Trustpilot & Yelp Reviews',
      channelCategory: 'review_trust',
      communityName: 'Trustpilot & Yelp: Buyer Review Intercept',
      threadTitle: `Negative Review Intercept: "Competitor product failed to deliver - who makes a legitimate version?"`,
      threadUrl: `https://www.trustpilot.com/search?query=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 96,
      buyerPainPoint: `Disappointed by inferior competitor alternatives and seeking an authentic, highly-recommended source for ${cleanName}.`,
      tailoredAdCopy: `A lot of competitors cut corners. ${cleanName} is designed to solve this exact issue with verified standards and customer satisfaction. Inspect the offer directly: ${deepLink}`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-4`,
      platform: 'Daily Trends (Google & Amazon)',
      channelCategory: 'daily_trends',
      communityName: 'Google Daily Trends & Amazon Movers',
      threadTitle: `Daily Breakout Spike: Searches for "${cleanName} best price and review" surged today`,
      threadUrl: `https://trends.google.com/trends/explore?q=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 95,
      buyerPainPoint: `Immediate buying intent driven by trending interest and active search engine discovery.`,
      tailoredAdCopy: `Searches for ${cleanName} are trending today. Get ahead of backorders and lock in your order with direct access here: ${deepLink}`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-5`,
      platform: 'Gumroad Discover',
      channelCategory: 'gumroad',
      communityName: 'Gumroad: Creator & Digital Product Discovery',
      threadTitle: `Top rated digital tools, guides & resources for ${cleanName}`,
      threadUrl: `https://gumroad.com/discover?query=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 92,
      buyerPainPoint: `Looking for specialized blueprints, templates, or companion guides related to ${cleanName}.`,
      tailoredAdCopy: `Level up your results with ${cleanName}. Designed for rapid implementation and seamless delivery: ${deepLink}`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-6`,
      platform: 'Pinterest',
      channelCategory: 'pinterest',
      communityName: 'Pinterest: Buyer Inspiration & Wishlist Boards',
      threadTitle: `Best ${cleanName} Guide & Top Recommendations for 2026`,
      threadUrl: `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 93,
      buyerPainPoint: `Visual shoppers pinning ideas and actively looking to purchase ${cleanName}.`,
      tailoredAdCopy: `Save this for your shopping list! If you need a top-rated solution for ${cleanName}, check out this link: ${deepLink}`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-7`,
      platform: 'LinkedIn',
      channelCategory: 'linkedin',
      communityName: 'LinkedIn: Professional Network Recommendations',
      threadTitle: `Seeking vendor and product recommendations for ${cleanName}`,
      threadUrl: `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 94,
      buyerPainPoint: `Professionals and business operators seeking reliable, vetted solutions for ${cleanName}.`,
      tailoredAdCopy: `For anyone needing a verified, high-performing solution for ${cleanName}, take a look at ${deepLink}. Solves the core operational bottleneck cleanly.`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    },
    {
      id: `lead-${Date.now()}-8`,
      platform: 'Reddit',
      channelCategory: 'community',
      communityName: 'r/AffiliateMarketing & Community Discussions',
      threadTitle: `What is the most honest, high-converting option for ${cleanName}?`,
      threadUrl: `https://www.reddit.com/search/?q=${encodeURIComponent(cleanName)}`,
      buyerIntentScore: 97,
      buyerPainPoint: `Looking for genuine community feedback and direct links without spam or friction.`,
      tailoredAdCopy: `If you want a proven setup that avoids friction, check out ${cleanName} (${deepLink}). Directly targets buyer intent so users find what they need and convert effortlessly.`,
      affiliateDeepLink: deepLink,
      status: 'Ready to Post'
    }
  ];
}

export function generateDeterministicStrategy(
  productName: string,
  productDescription: string
): PlatformCopy {
  const cleanName = productName.trim();
  const lower = (productName + ' ' + productDescription).toLowerCase();

  const isFinance = lower.includes('financ') || lower.includes('saving') || lower.includes('invest') || lower.includes('money') || lower.includes('apy');
  const isVideo = lower.includes('video') || lower.includes('tiktok') || lower.includes('reel') || lower.includes('youtube') || lower.includes('short');

  let platforms = ['Reddit', 'Facebook Groups', 'Quora', 'Twitter/X'];
  if (isVideo) {
    platforms = ['TikTok/Shorts', 'YouTube', 'Reddit', 'Facebook Groups'];
  }

  const keywords: string[] = [
    `${cleanName.toLowerCase()} review 2026`,
    `best ${cleanName.toLowerCase()} alternatives`,
    `how to use ${cleanName.toLowerCase()} for affiliate sales`,
    `high intent ${cleanName.toLowerCase()} discount code`,
    `honest buyer guide ${cleanName.toLowerCase()}`
  ];

  const questions: string[] = [
    `How does ${cleanName} compare to traditional solutions on the market?`,
    `What are the real conversion rates when using ${cleanName}?`,
    `Is ${cleanName} suitable for complete beginners with zero audience?`,
    `How do you bypass social platform link bans while promoting ${cleanName}?`,
    `What is the ROI timeframe after deploying ${cleanName}?`
  ];

  const microSearchTools: MicroSearchTool[] = [
    {
      id: `tool-${Date.now()}-1`,
      tool_title: `${cleanName} Instant Match Scout`,
      search_box_placeholder: `Search features, pricing, or workflows in ${cleanName}...`,
      target_intent: `Instant buyer intent matching and feature deep-linking for ${cleanName}.`,
      deep_link_base_url: `https://www.example.com/search?topic=${encodeURIComponent(cleanName)}&q=`
    },
    {
      id: `tool-${Date.now()}-2`,
      tool_title: `${cleanName} ROI & Conversion Calculator`,
      search_box_placeholder: 'Enter your monthly traffic or budget (e.g., 2,500 visits)...',
      target_intent: 'Simulate direct revenue projections and affiliate yield.',
      deep_link_base_url: `https://www.example.com/calculator?offer=${encodeURIComponent(cleanName)}&metric=`
    },
    {
      id: `tool-${Date.now()}-3`,
      tool_title: `${cleanName} Competitor Comparison Engine`,
      search_box_placeholder: 'Enter competing product name to see side-by-side specs...',
      target_intent: 'Unbiased side-by-side comparison bridge leading to direct conversion.',
      deep_link_base_url: `https://www.example.com/compare?product=${encodeURIComponent(cleanName)}&vs=`
    }
  ];

  const redditCopy = `A common trap in niche communities is dropping raw affiliate links without context. Instead, diagnose the root issue first. When someone asks about ${productDescription.slice(0, 80)}..., explain the architectural roadblock they are facing. Conclude with: "If you want to test the workflow without committing, check out this searchable directory and benchmark sheet." This builds community karma and drives frictionless conversions.`;

  const facebookCopy = `⚡ Stop wasting hours on manual bottlenecks!\n\nHere is how operators are using ${cleanName} to streamline ${productDescription.slice(0, 100)}:\n\n1️⃣ Automate repetitive research with intent-based micro search tools\n2️⃣ Route qualified leads directly through deep links\n3️⃣ Increase offer retention and CTR by 3.2x\n\nDrop a comment with "${cleanName.split(' ')[0].toUpperCase()}" and I'll send over the walkthrough guide + search portal!`;

  const quoraCopy = `Direct promotion will get your answers collapsed on Quora. Structure your answer using the 'Problem -> Mechanism -> Implementation' framework. Provide a comprehensive breakdown of ${cleanName}, citing concrete workflows and link to the dedicated search utility at the end of the technical explanation as a reference asset.`;

  const twitterCopy = `Most marketers overcomplicate their funnel.\n\nHere is how a single micro-search bridge for "${cleanName}" generated high-intent buyer traffic without ad spend 🧵👇`;

  return {
    target_platforms: platforms,
    keywords,
    questions,
    platform_copy: {
      'Reddit': {
        copy: redditCopy,
        strategy: `Post in relevant subreddits with >50k members. Deliver 90% upfront value before linking to bridge utility.`
      },
      'Facebook Groups': {
        copy: facebookCopy,
        strategy: `Target active niche practitioner groups. Respond to comments with custom search tool links within 10 minutes.`,
        hook: `How to unlock frictionless conversions using ${cleanName}`,
        visual_concept: `High-contrast diagram contrasting 3-step search engine flow vs outdated multi-page funnels.`
      },
      'Quora': {
        copy: quoraCopy,
        strategy: `Answer top-ranked questions on Google SERP. Include data table or step breakdown.`
      },
      'Twitter/X': {
        copy: twitterCopy,
        strategy: `Thread format with actionable takeaways. Pin tweet to profile for 48 hours.`
      }
    },
    micro_search_tools: microSearchTools
  };
}
